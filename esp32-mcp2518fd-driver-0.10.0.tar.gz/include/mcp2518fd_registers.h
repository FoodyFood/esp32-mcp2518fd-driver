#pragma once

#ifdef ARDUINO
#  include <Arduino.h>
#else
#  include <stdint.h>
#endif

// SPI Instructions
constexpr uint8_t MCP_CMD_RESET = 0x00;
constexpr uint8_t MCP_CMD_READ  = 0x30;
constexpr uint8_t MCP_CMD_WRITE = 0x20;

// SFR addresses
constexpr uint16_t REG_OSC      = 0xE00;
constexpr uint16_t REG_IOCON    = 0xE04;
constexpr uint16_t REG_CRC      = 0xE08;
constexpr uint16_t REG_ECCCON   = 0xE0C;
constexpr uint16_t REG_ECCSTAT  = 0xE10;
constexpr uint16_t REG_DEVID    = 0xE14;

constexpr uint16_t REG_CiCON    = 0x000;
constexpr uint16_t REG_CiNBTCFG = 0x004;
constexpr uint16_t REG_CiDBTCFG = 0x008;
constexpr uint16_t REG_CiTDC    = 0x00C;
constexpr uint16_t REG_CiTBC    = 0x010;
constexpr uint16_t REG_CiTSCON  = 0x014;
constexpr uint16_t REG_CiVEC    = 0x018;
constexpr uint16_t REG_CiINT    = 0x01C;
constexpr uint16_t REG_CiRXIF   = 0x020;
constexpr uint16_t REG_CiTXIF   = 0x024;
constexpr uint16_t REG_CiRXOVIF = 0x028;
constexpr uint16_t REG_CiTXATIF = 0x02C;
constexpr uint16_t REG_CiTXREQ  = 0x030;
constexpr uint16_t REG_CiTREC   = 0x034;
constexpr uint16_t REG_CiBDIAG0 = 0x038;
constexpr uint16_t REG_CiBDIAG1 = 0x03C;

// TEF (Transmit Event FIFO)
constexpr uint16_t REG_CiTEFCON = 0x040;
constexpr uint16_t REG_CiTEFSTA = 0x044;
constexpr uint16_t REG_CiTEFUA  = 0x048;
// 0x04C reserved

// TX Queue
constexpr uint16_t REG_CiTXQCON = 0x050;
constexpr uint16_t REG_CiTXQSTA = 0x054;
constexpr uint16_t REG_CiTXQUA  = 0x058;

// FIFO registers — each FIFO occupies 0x0C bytes: CON, STA, UA
// FIFO m (m = 1..31): base = 0x05C + (m-1)*0x0C
constexpr uint16_t REG_CiFIFOCON1 = 0x05C;
constexpr uint16_t REG_CiFIFOSTA1 = 0x060;
constexpr uint16_t REG_CiFIFOUA1  = 0x064;

constexpr uint16_t REG_CiFIFOCON2 = 0x068;
constexpr uint16_t REG_CiFIFOSTA2 = 0x06C;
constexpr uint16_t REG_CiFIFOUA2  = 0x070;

// Helper: compute CON/STA/UA address for any FIFO m (1-based)
inline constexpr uint16_t FIFO_CON(uint8_t m) { return 0x05C + (m - 1) * 0x0C; }
inline constexpr uint16_t FIFO_STA(uint8_t m) { return 0x060 + (m - 1) * 0x0C; }
inline constexpr uint16_t FIFO_UA(uint8_t m)  { return 0x064 + (m - 1) * 0x0C; }

// Filter registers (DS20006027B Register 3-32, page 60)
// CiFLTCONm: one register per 4 filters, each filter occupies one byte
// byte layout per filter: [FLTEN | — | — | FnBP[4:0]]
// Register for filter n: 0x1D0 + (n/4)*4
// Byte offset within register: n%4 (byte 0 = bits[7:0])
constexpr uint16_t REG_CiFLTCON0 = 0x1D0;
// CiFLTOBJn / CiMASKn: stride 8 bytes per filter
// CiFLTOBJn = 0x1F0 + n*8,  CiMASKn = 0x1F4 + n*8  (DS20006027B page 13)
constexpr uint16_t REG_CiFLTOBJ0 = 0x1F0;
constexpr uint16_t REG_CiMASK0   = 0x1F4;

inline constexpr uint16_t FLTOBJ(uint8_t n) { return 0x1F0 + (uint16_t)n * 8; }
inline constexpr uint16_t FLTMSK(uint8_t n) { return 0x1F4 + (uint16_t)n * 8; }
inline constexpr uint16_t FLTCON_REG(uint8_t n) { return 0x1D0 + ((uint16_t)n / 4) * 4; }
inline constexpr uint8_t  FLTCON_BYTE(uint8_t n) { return n % 4; }  // byte offset within register

// RAM
constexpr uint16_t RAM_BASE = 0x400;

// CiFIFOCONm bit positions (Register 3-29, DS20006027B page 54)
// bits 31-29: PLSIZE[2:0]  bits 28-24: FSIZE[4:0]
// bits 22-21: TXAT[1:0]  bits 20-16: TXPRI[4:0]
// bit 10: FRESET  bit 9: TXREQ  bit 8: UINC
// bit 7: TXEN  bit 6: RTREN  bit 5: RXTSEN  bit 0: TFNRFNIE
constexpr uint32_t FIFOCON_PLSIZE_SHIFT = 29;
constexpr uint32_t FIFOCON_FSIZE_SHIFT  = 24;
constexpr uint32_t FIFOCON_TXAT_3       = (1u << 21);  // TXAT=01: 3 retransmission attempts
constexpr uint32_t FIFOCON_FRESET       = (1u << 10);
constexpr uint32_t FIFOCON_TXREQ        = (1u << 9);
constexpr uint32_t FIFOCON_UINC         = (1u << 8);
constexpr uint32_t FIFOCON_TXEN         = (1u << 7);
constexpr uint32_t FIFOCON_RTREN        = (1u << 6);
constexpr uint32_t FIFOCON_RXTSEN       = (1u << 5);
constexpr uint32_t FIFOCON_TFNRFNIE     = (1u << 0);  // TX/RX not-full/not-empty interrupt enable

// PLSIZE values (DS20006027B page 54)
constexpr uint8_t PLSIZE_8  = 0;
constexpr uint8_t PLSIZE_12 = 1;
constexpr uint8_t PLSIZE_16 = 2;
constexpr uint8_t PLSIZE_20 = 3;
constexpr uint8_t PLSIZE_24 = 4;
constexpr uint8_t PLSIZE_32 = 5;
constexpr uint8_t PLSIZE_48 = 6;
constexpr uint8_t PLSIZE_64 = 7;

// CiFIFOSTAm bit positions (Register 3-30, DS20006027B page 57)
// bits 12-8: FIFOCI[4:0]
// bit 7: TXABT  bit 6: TXLARB  bit 5: TXERR
// bit 4: TXATIF  bit 3: RXOVIF
// bit 2: TFERFFIF  bit 1: TFHRFHIF  bit 0: TFNRFNIF
constexpr uint32_t FIFOSTA_TXABT    = (1u << 7);
constexpr uint32_t FIFOSTA_TXLARB   = (1u << 6);
constexpr uint32_t FIFOSTA_TXERR    = (1u << 5);
constexpr uint32_t FIFOSTA_TXATIF   = (1u << 4);
constexpr uint32_t FIFOSTA_RXOVIF   = (1u << 3);
constexpr uint32_t FIFOSTA_TFERFFIF = (1u << 2);
constexpr uint32_t FIFOSTA_TFHRFHIF = (1u << 1);
constexpr uint32_t FIFOSTA_TFNRFNIF = (1u << 0);

// CiTREC bit masks (Register 3-20, DS20006027B page 43)
// bits 7:0  = REC[7:0], bits 15:8 = TEC[7:0], bits 23:16 = flags
constexpr uint32_t TREC_EWARN  = (1u << 16);  // TEC or REC >= 96
constexpr uint32_t TREC_RXWARN = (1u << 17);  // REC >= 96
constexpr uint32_t TREC_TXWARN = (1u << 18);  // TEC >= 96
constexpr uint32_t TREC_RXBP   = (1u << 19);  // REC >= 128 (error passive)
constexpr uint32_t TREC_TXBP   = (1u << 20);  // TEC >= 128 (error passive)
constexpr uint32_t TREC_TXBO   = (1u << 21);  // TEC > 255 (bus-off)

// CiBDIAG1 bit masks (Register 3-22, DS20006027B page 45)
constexpr uint32_t BDIAG1_NACKERR = (1u << 18);  // transmitted message not acknowledged
constexpr uint32_t BDIAG1_TXBOERR = (1u << 23);  // device went to bus-off

// CiTSCON bit positions (DS20006027B Register 3-12, page 33)
// bit 16 = TBCEN: enable free-running time base counter
// bit 17 = TSEOF: 1 = timestamp at EOF, 0 = timestamp at SOF
// bits 9:0 = TBCPRE: prescaler (0 = increment every 1 FSYS clock)
constexpr uint32_t TSCON_TBCEN = (1u << 16);

// OSC register bit positions (DS20006027B Register 3-1, page 16)
// bit 2 = OSCDIS: oscillator disabled (reads 1 in Sleep mode; clear to wake)
// bits 6:5 = CLKODIV[1:0]: clock output divisor
//   00=÷1  01=÷2  10=÷4  11=÷10 (reset default = 11)
constexpr uint32_t OSC_OSCDIS          = (1u << 2);
constexpr uint8_t  OSC_CLKODIV_SHIFT   = 5;
constexpr uint8_t  OSC_CLKODIV_DIV1    = 0x00u;  // 00 = ÷1
constexpr uint8_t  OSC_CLKODIV_DIV2    = 0x01u;  // 01 = ÷2
constexpr uint8_t  OSC_CLKODIV_DIV4    = 0x02u;  // 10 = ÷4
constexpr uint8_t  OSC_CLKODIV_DIV10   = 0x03u;  // 11 = ÷10 (reset default)

// IOCON byte 3 (bits 31:24) — PM1/PM0 configure INT1/INT0 as interrupt or GPIO
// DS20006027B Register 3-2, page 18. Must be written byte-by-byte.
// PM1=0: INT1 = RX interrupt (CiINT.RXIF & RXIE)  PM1=1: GPIO1 (reset default)
// PM0=0: INT0 = TX interrupt (CiINT.TXIF & TXIE)  PM0=1: GPIO0 (reset default)
constexpr uint8_t IOCON3_PM1 = (1u << 1);  // bit 25 of IOCON = byte 3 bit 1

// CiRXOVIF: bit N = FIFO N overflowed; FIFO2 = bit 2
constexpr uint32_t RXOVIF_FIFO2 = (1u << 2);

// CiCON byte 2 bits (bits 23:16)
constexpr uint8_t  CON2_RTXAT           = (1u << 0);  // bit 16 — restrict retransmission attempts
constexpr uint32_t CON_REQOP_SHIFT = 24;
constexpr uint32_t CON_OPMOD_SHIFT = 21;

constexpr uint32_t CON_REQOP_MASK = 0x7u << CON_REQOP_SHIFT;
constexpr uint32_t CON_OPMOD_MASK = 0x7u << CON_OPMOD_SHIFT;

// CiINT byte 2 bits (bits 23:16 of CiINT at 0x01C)
// bit 17 of CiINT = byte 2 bit 1 = RXIE: RX FIFO interrupt enable
constexpr uint8_t  CINT2_RXIE = (1u << 1);  // DS20006027B Register 3-14 bit 17

// Operating modes
constexpr uint8_t MODE_NORMAL      = 0;
constexpr uint8_t MODE_SLEEP       = 1;
constexpr uint8_t MODE_INTERNAL_LB = 2;
constexpr uint8_t MODE_LISTEN      = 3;
constexpr uint8_t MODE_CONFIG      = 4;
constexpr uint8_t MODE_EXTERNAL_LB = 5;
constexpr uint8_t MODE_CLASSIC     = 6;
constexpr uint8_t MODE_RESTRICTED  = 7;